#include <Qt/qapplication.h>
#include <QtGui/QtGui>
#include <Qt/qlabel.h> 
#include <qt/qtimer.h>

#include "mainwindow.h"  

class QTimer;

LPDIRECT3DDEVICE9 pd3dDevice;

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QTimer * timer = new QTimer();
    MainWindow *mainWindow = new MainWindow(/*0, Qt::CustomizeWindowHint*/);
    //mainWindow->setFixedSize(mainWindow->sizeHint());
    mainWindow->show();
    if(!mainWindow->initDirect3D())
     {
        QMessageBox::information(0, QLabel::tr("Direct3D"),
             QLabel::tr("Cannot initializing Direct3D"));
         return 0;
     }
    mainWindow->Init();
//    timer->setInterval(0);
    QObject::connect(timer, SIGNAL(timeout()), mainWindow, SLOT(Rendering()));
    timer->start();
    return app.exec();
}